export const AVATAR_DEFAULT =
  'https://i.pinimg.com/originals/7c/c7/a6/7cc7a630624d20f7797cb4c8e93c09c1.png';

export const LOGROCKET_KEY = 'w7gyvs/mf2-web';
